package com.cg.anurag.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.anurag.dto.Users;

public interface UsersDao extends JpaRepository<Users, Long>
{

}
