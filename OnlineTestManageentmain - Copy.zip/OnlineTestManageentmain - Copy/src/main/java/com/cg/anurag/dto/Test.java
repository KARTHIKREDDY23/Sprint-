package com.cg.anurag.dto;


	import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.Column;
	@Entity
	public class Test
	{
	   @Id	
	   @Column(name="test_id")
	   int testId;
	   @Column(name="test_title")
	   String testTitle;
	   @Column(name="test_duration")
	   String testDuration;
	   @Column(name="test_totalMarks")
	   double testTotalMarks;
	   public Test() {}
	public Test(int testId, String testTitle, String testDuration, double testTotalMarks) {
		super();
		this.testId = testId;
		this.testTitle = testTitle;
		this.testDuration = testDuration;
		this.testTotalMarks = testTotalMarks;
	}
	public int getTestId() {
		return testId;
	}
	public void setTestId(int testId) {
		this.testId = testId;
	}
	public String getTestTitle() {
		return testTitle;
	}
	public void setTestTitle(String testTitle) {
		this.testTitle = testTitle;
	}
	public String getTestDuration() {
		return testDuration;
	}
	public void setTestDuration(String testDuration) {
		this.testDuration = testDuration;
	}
	public double getTestTotalMarks() {
		return testTotalMarks;
	}
	public void setTestTotalMarks(double testTotalMarks) {
		this.testTotalMarks = testTotalMarks;
	}
	   
}
