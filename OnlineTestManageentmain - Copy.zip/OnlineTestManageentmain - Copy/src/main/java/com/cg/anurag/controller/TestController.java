package com.cg.anurag.controller;


	import java.util.List;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.dto.Test;
import com.cg.anurag.exceptions.UserException;
import com.cg.anurag.service.TestService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RestController 
	public class TestController
	{
		@Autowired
		TestService testService;
		public void setTestService(TestService testService)
		{
			this.testService=testService;
		}
		
	  
	  
	   @GetMapping("/getTests")
	   public List<Test> getTests()
	   {
		   return testService.getTests();
	   }

	   @PostMapping(value="/addTest",consumes="application/json")
	   public ResponseEntity<String> insertTest(@RequestBody()Test test)
	   {
		   String message="Test Inserted Successfully";
		   if(testService.insertTest(test)==null)
			   message="Test Insertion Failed";
		   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	   }
	   
	   @PutMapping(value="/updateTest",consumes="application/json")
	   public String updateBook(@RequestBody()Test test)
	   {
		   String message=testService.updateTest(test);
		   return message;
	   }
	   
	   @DeleteMapping("/deleteTest/{testId}")
	   public String deleteTest(@PathVariable int testId)
	   {
		   return testService.deleteTest(testId); 
	   }
	   @GetMapping(value = "assigntest/{userId}/{testId}", produces = "application/json")
		public Test showAssignTest(@PathVariable long userId,@PathVariable int testId) {
			try {
				return testService.assignTest(userId, testId);
			} catch (UserException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		@RequestMapping(value = "assigntestsubmit", method = RequestMethod.POST)
		public String assignTest(@RequestParam("testid") int testId, @RequestParam("userid") long userId) {
			try {
				testService.assignTest(userId, testId);
			} catch (UserException e) {
				System.out.println(e.getMessage());
			}
			return "admin";
		}

	}
	