package com.cg.anurag.exceptions;


public class ExceptionMessage {
	
	public static final String TESTMESSAGE = "The test does not exist or is already assigned";
	
	private ExceptionMessage() {
		super();
	}

}