package com.cg.anurag.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.dao.TestDAO;
import com.cg.anurag.dao.UsersDao;
import com.cg.anurag.dto.Test;
import com.cg.anurag.dto.Users;
import com.cg.anurag.exceptions.ExceptionMessage;
import com.cg.anurag.exceptions.UserException;

@Service
public class TestService 
{
    @Autowired
    TestDAO tdao;
    @Autowired
    UsersDao udao;
    public void setTdao(TestDAO tdao) { this.tdao=tdao;}
    public void setUdao(UsersDao udao) { this.udao=udao;}
    @Transactional
    public Test insertTest(Test test)
    {
        return tdao.save(test);
    }
    
    @Transactional(readOnly=true)
    public List<Test> getTests()
    {
    	return tdao.findAll();
    }
    @Transactional
    public String deleteTest(int testId)
    {
    	tdao.deleteById(testId);
    	return "Test Deleted";
    }
    
    @Transactional
    public String updateTest(Test newTest)
    {
    	Test test = tdao.findById(newTest.getTestId()).get();
    	if(test!=null)
    	{
    	  test.setTestTitle(newTest.getTestTitle());
    	  test.setTestDuration(newTest.getTestDuration());
    	  test.setTestTotalMarks(newTest.getTestTotalMarks());
    	  return "Test Modified";
    	}
    	return "Update Failed";
    }
    @Transactional
    public Test assignTest(Long userId, int testId) throws UserException {
		Users user = udao.findById(userId).get();
		System.out.println(user==null);
		Test test = tdao.findById(testId).get();
		System.out.println(test==null);
		user.setUserTest(test);
		
		if (test == null) {
			throw new UserException(ExceptionMessage.TESTMESSAGE);
		}
		
		 else {
			user.setUserTest(test);
			
		}
		tdao.save(test);
		udao.save(user);
		return test;
	} 
}
